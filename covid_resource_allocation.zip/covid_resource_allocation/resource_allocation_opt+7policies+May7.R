#model May 2nd
#SIR-VM

#clean workspace
rm(list = ls())
gc()

#load packages
sapply(c('dplyr', 'deSolve', 
         'readxl', 'stringr', 
         'reshape2', 'ggplot2', 
         'varhandle', 'here', 'readr',
         'gtools', 'plotly', 'MASS', 'utils'), require, character.only=T)

#set in directory and out directory
#Make sure you have the resource_allocation.Rproj open, otherwise 
#you will need to change the working directory manually.
#indir <- paste0(here(),'/param_files')
outdir <- paste0(here(),'/model_outputs/covid_vaccines/May2')
setwd(outdir)

####8 REGIONS####
regional_attributes_df<-expand.grid('mort_rate'= c(.01, .05), 
                                  'contact_rate' = c(5, 25),
                                 'initial_prevalence' = c(.001, .005))

regional_attributes_df$region_id = 1:nrow(regional_attributes_df)


REGION_SET<-regional_attributes_df$region_id

####5 COVID Compartments###
COVID_SET<-1:5
SIRV_SUBSET<-1:4 #for finding the denominator of FOI
ELIGIBLE_SUBSET<-c(1,3) #eligible populations
S_SUBSET<-1
I_SUBSET<-2
R_SUBSET<-3
V_SUBSET<-4
M_SUBSET<-5

####15 POLICIES####
policy_df<-data.frame(permutations(n=2,r=4,v=0:1,repeats.allowed=T))
colnames(policy_df)<-c('pop', 'prev', 'contact', 'mort')
policy_df<-policy_df%>%
  filter(rowSums(across(where(is.numeric)))!=0)
policy_df$policy_id<-1:nrow(policy_df)
POLICY_SET<-policy_df$policy_id
#######Parameters########

#model evaluation
start_month = 1
n_novax_periods = 0
n_allocation_periods = 10
end_month = n_novax_periods+n_allocation_periods+1 #10 months warm up (before vaccines), ~10 months to distribute vaccines

#other
gamma<-2 #recovery rate
epsilon<-.05 #diminished FOI
x_total<-80000 #number of vaccines allocated per month (when available)
migration_rate<-.01

#mortality rates
mu_r<-rep(0, times = length(REGION_SET))

for (r in REGION_SET){
  temp<-unlist(regional_attributes_df['mort_rate'])
  mu_r[r]<-temp[r]
}

beta_r_r<-array(0, dim = c(length(REGION_SET),
                         length(REGION_SET)))
beta_r<-rep(0, times = max(REGION_SET))
beta_r<-unlist(regional_attributes_df['contact_rate'])

#effective contact rates
lapply(REGION_SET, function(r1){
  lapply(REGION_SET, function(r2){
    r1_temp<-beta_r[r1]
    r2_temp<-beta_r[r2]
    
    beta_r_r[r1,r2]<<-if_else(r1 == r2, 1, migration_rate)*(r1_temp)^(1/2)*(r2_temp)^(1/2)
  })
})

###pop init####
N_init<-array(0, dim = c(length(COVID_SET),
                         length(REGION_SET)))

start_pop_r<-rep(100000, times = length(REGION_SET))

lapply(REGION_SET, function(r){
  temp<-unlist(regional_attributes_df['initial_prevalence'])
  N_init[I_SUBSET, r]<<-temp[r]*start_pop_r[r]
  N_init[S_SUBSET, r]<<-(1-temp[r])*start_pop_r[r]
})

compartment_names<-c()

for(r in REGION_SET){
  for(c in COVID_SET){
    compartment_names<-c(compartment_names, paste0('N_', c, '_', r))
  }
}

N_init<-c(N_init)
names(N_init)<-compartment_names


#N_ref
N_c_r_ref<-array(0, dim = c(length(COVID_SET),
                            length(REGION_SET)))
n = 1


for (r in REGION_SET){
  for (c in COVID_SET){
    N_c_r_ref[c,r]<-n
    n<-n+1
  }
}


###generate policy allocation ref####
policy_allocation_total<-array(0, dim = c(length(REGION_SET), 
                                         length(POLICY_SET),
                                         end_month-start_month+1))

remaining_vaccines_temp_r<-rep(0, times = length(REGION_SET))

#pop allocation
policy_allocation_gen<-function(pop_current, current_allocation_period_temp, 
                                policy_eval){
    
  unvax_pop_r<-rep(0, times = length(REGION_SET))
  prev_policy_r<-rep(0, times = length(REGION_SET))
  mortality_policy_r<-rep(0, times = length(REGION_SET))
  beta_policy_r<-rep(0, times = length(REGION_SET))
  
  for (r in REGION_SET){
    
    #calculate the total unvaccined population in each state
    unvax_pop_r[r]<-start_pop_r[r]-pop_current[N_c_r_ref[V_SUBSET, r]]-
      pop_current[N_c_r_ref[M_SUBSET, r]]
    
    #assign a value of 0 if everyone eligible is vaccinated
    prev_policy_r[r]<-if_else(unvax_pop_r[r] == 0, 0, pop_current[N_c_r_ref[I_SUBSET, r]])
    mortality_policy_r[r]<-if_else(unvax_pop_r[r] == 0, 0, mu_r[r])
    beta_policy_r[r]<-if_else(unvax_pop_r[r] == 0, 0, beta_r[r])
    
  }
  
  current_policy_df<-policy_df[policy_eval,]
  policy_calc<-rep(0, times = length(REGION_SET))
  
  for (r in REGION_SET){
    if(unvax_pop_r[r] > 0){
      if(current_policy_df[1] == 1){
        policy_calc[r]<-(unvax_pop_r[r]/sum(unvax_pop_r))
      }
      if(current_policy_df[2] == 1){
        policy_calc[r]<-policy_calc[r]+(prev_policy_r[r]/sum(prev_policy_r))
      }
      if(current_policy_df[3] == 1){
        policy_calc[r]<-policy_calc[r]+(beta_policy_r[r]/sum(beta_policy_r))
      }
      if(current_policy_df[4] == 1){
        policy_calc[r]<-policy_calc[r]+(mortality_policy_r[r]/sum(mortality_policy_r))
      }
    }
  }
  
  policy_calc<-policy_calc/sum(policy_calc)
  n_allocated_r<-rep(0, times = length(REGION_SET))
  
  for (r in REGION_SET){
    temp<-min(unvax_pop_r[r], round(policy_calc[r]*x_total))
    n_allocated_r[r]<-max(100, temp)
    #n_allocated_r[r]<-max(100, n_allocated_r[r])
    #print(n_allocated_r)
  }
  
  n_allocated_r<-((n_allocated_r/sum(n_allocated_r))*x_total)
  
  remaining_vaccines_temp_r<<-round(n_allocated_r)
  
  policy_allocation_total[REGION_SET,
                          policy_eval, 
                          current_allocation_period_temp]<<-round(n_allocated_r)
}

SIR_VM_model <- function(time, N_c_r, parms) {
  
  print(time)
  
  dN_c_r <- array(0, dim = length(COVID_SET)*length(REGION_SET))
  
  #to determine if moving into a new resource allocation period
  current_allocation_period_temp<-as.integer(time)+1
  unvax_pop_r<-start_pop_r-N_c_r[N_c_r_ref[V_SUBSET, REGION_SET]]-
    N_c_r[N_c_r_ref[M_SUBSET, REGION_SET]]
  
  #print(unvax_pop_r)
  
  if(current_allocation_period_temp > current_allocation_period){ #if in new allocation period
    if(current_allocation_period_temp > n_novax_periods){ #if not in warmup period
      if(current_allocation_period_temp < end_month){ #ensures no allocation the last month
        if(sum(unvax_pop_r)>0){ #if there are still people left to vaccinate
          policy_allocation_gen(N_c_r, current_allocation_period_temp, policy_eval)
          current_allocation_period<-current_allocation_period_temp
          #print(current_allocation_period)
        }
      }
    }
  }
  
  #to determine vaccination rates
  vaccination_rates_r<-array(0, dim = c(length(REGION_SET)))
  
  if(current_allocation_period_temp > n_novax_periods){ #if not in warmup period
      for (r in REGION_SET){
        if(unvax_pop_r[r]>0){
        eligible_pop<-round(sum(N_c_r[N_c_r_ref[ELIGIBLE_SUBSET,r]]))
        
        
        
        if(eligible_pop > 0){
          vaccination_rates_r[r]<-
            policy_allocation_total[r,policy_eval,
                                    current_allocation_period_temp]/eligible_pop
        }
      }
    }
    #print(vaccination_rates_r)
  }
  
  #remaining_vaccines_temp_r<<-remaining_vaccines_temp_r-
  #  (vaccination_rates_r*(N_c_r[N_c_r_ref[R_SUBSET, REGION_SET]]+
  #                          N_c_r[N_c_r_ref[S_SUBSET, REGION_SET]]))
  
  #force of infection calculations
  FOI_r<-rep(0, times = length(REGION_SET))
  for (r in REGION_SET){
   FOI_r[r]<-sum(beta_r_r[r, REGION_SET]*
     (N_c_r[N_c_r_ref[I_SUBSET, REGION_SET]]/sum(N_c_r)))
  }
  
  #Susceptible Compartments
  for (r in REGION_SET){
    dN_c_r[N_c_r_ref[S_SUBSET,r]]<- -FOI_r[r]*N_c_r[N_c_r_ref[S_SUBSET,r]] -
      N_c_r[N_c_r_ref[S_SUBSET,r]]*vaccination_rates_r[r]
  }
  
  #Infectious Compartments
  for (r in REGION_SET){
    dN_c_r[N_c_r_ref[I_SUBSET,r]]<-FOI_r[r]*N_c_r[N_c_r_ref[S_SUBSET,r]]+
      epsilon*FOI_r[r]*N_c_r[N_c_r_ref[R_SUBSET,r]]-
      gamma*N_c_r[N_c_r_ref[I_SUBSET,r]]-
      mu_r[r]*N_c_r[N_c_r_ref[I_SUBSET,r]]
  }
  
  #Recovered Compartments
  for (r in REGION_SET){
    dN_c_r[N_c_r_ref[R_SUBSET,r]]<- gamma*N_c_r[N_c_r_ref[I_SUBSET,r]]-
      epsilon*FOI_r[r]*N_c_r[N_c_r_ref[R_SUBSET,r]]-
      N_c_r[N_c_r_ref[R_SUBSET,r]]*vaccination_rates_r[r]
  }
  
  #vaccination
  for (r in REGION_SET){
    dN_c_r[N_c_r_ref[V_SUBSET,r]]<-N_c_r[N_c_r_ref[S_SUBSET,r]]*vaccination_rates_r[r]+
      N_c_r[N_c_r_ref[R_SUBSET,r]]*vaccination_rates_r[r]
  }
  
  #mortality
  for (r in REGION_SET){
    dN_c_r[N_c_r_ref[M_SUBSET,r]]<-
      mu_r[r]*N_c_r[N_c_r_ref[I_SUBSET, r]]
  }
    
    return(list(dN_c_r))
} 

#Time Horizon and Evaluation intervals (1 month)
TT<-end_month-start_month
time_interval <- 1/30 #daily
TT_SET <- seq(from = 0, to = TT, by = time_interval)
out_df_all<-data.frame()

#to track allocation periods and current policy being evaluated
#(set to 0 to calculate first allocation periods)
current_allocation_period<-0
policy_eval<-1

for (p in POLICY_SET){
  
  current_allocation_period<-0
  start<-Sys.time()
  policy_eval<<-p
  print(policy_eval)
  
  out_df<-as.data.frame(ode(times = TT_SET, y = N_init, 
                            func = SIR_VM_model, method = 'lsoda',
                            parms = NULL))
    
  out_df<- cbind(policy_id = rep(p, times = nrow(out_df)),
                 out_df)
    
  out_df_all<-rbind(out_df_all, out_df)
}
 
out_df_test<-read.csv('out.csv')

#end<-print(Sys.time()-start)
analysis_df <- melt(out_df_test, id=c("policy_id","time"))
analysis_df <- cbind(analysis_df, 
                     data.frame(do.call('rbind', 
                                        strsplit(as.character(analysis_df$variable),
                                                 '_',fixed=TRUE))))

names(analysis_df)[names(analysis_df) == "X2"] <- "COVID_compartment"
names(analysis_df)[names(analysis_df) == "X3"] <- "Region_compartment"
analysis_df = subset(analysis_df, select = -c(X1))

#test to make sure vax+mort == 100,000
test<-analysis_df%>%
  group_by(policy_id, COVID_compartment, Region_compartment)%>%
  summarise(total = max(value))%>%
  filter(COVID_compartment %in% c(4,5))%>%
  group_by(policy_id)%>%
  summarise(total_vax_mort = sum(total))

vax_overtime_df<-analysis_df%>%
  filter(COVID_compartment == V_SUBSET)

ggplot(data=vax_overtime_df, aes(x=time, y=value, group=policy_id)) +
  geom_line(color=policy_id)#+
  #geom_point(color="red", size=3)





#write.csv(analysis_df, 'out_min100vax.csv')


key_indicators_df<-analysis_df%>%
  filter(time == TT, 
         COVID_compartment == M_SUBSET)%>%
  group_by(policy_id)%>%
  summarise(total_mort = sum(value),
            max_mort = max(value),
            min_mort = min(value))%>%
  left_join(analysis_df%>%
              filter(time == TT, COVID_compartment == V_SUBSET)%>%
              group_by(policy_id)%>%
              summarise(max_vax = max(value),
                        min_vax = min(value),
                        eq_vax = max_vax - min_vax)%>%
              mutate(eq_factor = eq_vax/sum(eq_vax)))%>%
  ungroup()%>%
  mutate(eq_factor = 1- (eq_factor-min(eq_factor))/max(eq_factor)-min(eq_factor))

key_indicators_graph<-ggplot(data = key_indicators_df,
       aes(y=eq_factor, x=total_mort))+
  geom_point()+
  geom_text(label=key_indicators_df$policy_id,
            nudge_x = 0.001, nudge_y = 0.05, 
            check_overlap = F)#+
  #xlim(550, 610)

png('key_indicators_graph.png')#, width = 500, height = 500)
print(key_indicators_graph)
dev.off()

for (policy_id in POLICY_SET){
  temp_df<-as.data.frame(policy_allocation_total[REGION_SET, 
                                                 policy_id,
                                                 1:5])
  colnames(temp_df)<-1:5
  temp_df<-cbind(community_id = REGION_SET, temp_df)
  temp_df<-melt(temp_df, id.vars = c('community_id'))
  colnames(temp_df)<-c('region_id', 'allocation_period', 'number_of_vaccines_allocated')
  
  allocation_graph<-ggplot(data = temp_df, aes(x = allocation_period,
                                               y = number_of_vaccines_allocated,
                                               group = as.factor(region_id)))+
    geom_line(aes(color=as.factor(region_id)))+
    #lims(y = c(0,12000))+
    labs(title = paste0('policy ', policy_id))
  
  png(paste0('allocation_graph_policy_', policy_id, '.png'))#, width = 500, height = 500)
  print(allocation_graph)
  dev.off()
}


#write_csv(key_indicators_df, 'key_indicators_big_beta_diff.csv')

