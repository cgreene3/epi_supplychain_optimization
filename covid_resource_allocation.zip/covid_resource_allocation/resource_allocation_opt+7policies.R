#model March 28th
#SIR-VM

#clean workspace
rm(list = ls())
gc()

#load packages
sapply(c('dplyr', 'deSolve', 
         'readxl', 'stringr', 
         'reshape2', 'ggplot2', 
         'varhandle', 'here', 'readr',
         'gtools', 'plotly', 'MASS'), require, character.only=T)

#set in directory and out directory
#Make sure you have the resource_allocation.Rproj open, otherwise 
#you will need to change the working directory manually.
#indir <- paste0(here(),'/param_files')
outdir <- paste0(here(),'/model_outputs/covid_vaccines/Apr18/increased_mortality')
setwd(outdir)

####8 Communities####
COMMUNITY_SET<-1:8

####5 COVID Compartments###
COVID_SET<-1:5
SIRV_SUBSET<-1:4 #for finding the denominator of FOI
ELIGIBLE_SUBSET<-c(1,3) #eligible populations
S_SUBSET<-1
I_SUBSET<-2
R_SUBSET<-3
V_SUBSET<-4
M_SUBSET<-5

####7 POLICIES####
POLICY_SET<-1:15

#######Parameters########

#model evaluation
start_month = 1
end_month = 7

#other
gamma<-2 #recovery rate
epsilon<-.05 #diminished FOI
x_total<-80000 #number of vaccines allocated per month

community_attributes<-expand.grid('mort_rate'= c('L', 'H'), 
                                  'contact_rate' = c('L', 'H'), 
                                  'prev'= c('L', 'H'))

community_attributes$community_id = 1:nrow(community_attributes)

#mortality rates
mu_c<-rep(0, times = length(COMMUNITY_SET))

for (c in COMMUNITY_SET){
  temp<-unlist(community_attributes['mort_rate'])
  mu_c[c]<-if_else(temp[c] == 'L', .01, .5)
}

beta_c_c<-array(0, dim = c(length(COMMUNITY_SET),
                         length(COMMUNITY_SET)))

#effective contact rates
lapply(COMMUNITY_SET, function(c1){
  lapply(COMMUNITY_SET, function(c2){
    temp<-unlist(community_attributes['contact_rate'])
    c1_temp<-if_else(temp[c1] == 'L', 10, 30)
    c2_temp<-if_else(temp[c2] == 'L', 10, 30)
    
    beta_c_c[c1,c2]<<-if_else(c1 == c2, 1, .01)*(c1_temp)^(1/2)*(c2_temp)^(1/2)
  })
})

###pop init####
N_init<-array(0, dim = c(length(COVID_SET),
                         length(COMMUNITY_SET)))

start_pop_c<-rep(100000, times = length(COMMUNITY_SET))

lapply(COMMUNITY_SET, function(c){
  temp<-unlist(community_attributes['prev'])
  N_init[I_SUBSET, c]<<-if_else(temp[c] == 'L', .001, .005)*start_pop_c[c]
  N_init[S_SUBSET, c]<<-if_else(temp[c] == 'L', 1-.001, 1-.005)*start_pop_c[c]
})

compartment_names<-c()

for(r in COMMUNITY_SET){
  for(c in COVID_SET){
    compartment_names<-c(compartment_names, paste0('N_', c, '_', r))
  }
}

N_init<-c(N_init)
names(N_init)<-compartment_names


#N_ref
N_c_r_ref<-array(0, dim = c(length(COVID_SET),
                            length(COMMUNITY_SET)))
n = 1


for (r in COMMUNITY_SET){
  for (c in COVID_SET){
    N_c_r_ref[c,r]<-n
    n<-n+1
  }
}


###generate policy allocation ref####
policy_allocation_total<-array(0, dim = c(length(COMMUNITY_SET), 
                                         length(POLICY_SET),
                                         end_month-start_month))

#pop allocation
pop_policy_temp<-rep(x = (1/length(COMMUNITY_SET))*x_total, times = length(COMMUNITY_SET))
mortality_policy_temp<-(mu_c/sum(mu_c))*x_total
beta_policy_temp<-(beta_c_c[r,COMMUNITY_SET])

policies_that_change_overtime<-c(2,4,6,7)

policy_allocation_gen<-function(pop_current, current_allocation_period_temp, policy_eval){
  
  #infection rate allocation (changes overtime)
  infection_rate_policy_temp<-rep(0, times = length(COMMUNITY_SET))
  for (r in COMMUNITY_SET){
    infection_rate_policy_temp[r]<-sum(beta_c_c[r, COMMUNITY_SET]*
                    (pop_current[N_c_r_ref[I_SUBSET, COMMUNITY_SET]]/sum(pop_current)))*pop_current[N_c_r_ref[S_SUBSET, r]]
  }
  infection_rate_policy_temp<-(infection_rate_policy_temp/sum(infection_rate_policy_temp))*x_total
  
  #pop only
  if (policy_eval == 1){
    policy_allocation_total[COMMUNITY_SET, policy_eval, current_allocation_period_temp]<<-
      pop_policy_temp
  }
  
  #infection rate only
  if (policy_eval == 2){
    policy_allocation_total[COMMUNITY_SET, policy_eval, current_allocation_period_temp]<<-
      infection_rate_policy_temp
  }
  
  #mortality only
  if (policy_eval == 3){
    policy_allocation_total[COMMUNITY_SET, policy_eval, current_allocation_period_temp]<<-
      mortality_policy_temp
  }
  
  #infection rate and mortality rate
  if (policy_eval == 4){
    policy_temp<-(infection_rate_policy_temp+mortality_policy_temp)/2
    policy_allocation_total[COMMUNITY_SET, policy_eval, current_allocation_period_temp]<<-
      policy_temp
  }
  
  #mortality and pop
  if (policy_eval == 5){
    policy_allocation_total[COMMUNITY_SET, policy_eval, current_allocation_period_temp]<<-
      (mortality_policy_temp+pop_policy_temp)/2
  }
  
  #infection rate and pop
  if (policy_eval == 6){
    policy_temp<-(infection_rate_policy_temp+pop_policy_temp)/2
    policy_allocation_total[COMMUNITY_SET, policy_eval, current_allocation_period_temp]<<-
      policy_temp
  }
  
  if (policy_eval == 7){
    policy_temp<-(infection_rate_policy_temp+pop_policy_temp+mortality_policy_temp)/3
    policy_allocation_total[COMMUNITY_SET, policy_eval, current_allocation_period_temp]<<-
      policy_temp
  }
}

SIR_VM_model <- function(time, N, parms) {
  
  print(time)
  
  dN <- array(0, dim = length(COVID_SET))
  
  #to determine if moving into a new resource allocation period
  current_allocation_period_temp<-as.integer(time)+1
  
  if(current_allocation_period_temp > current_allocation_period){
    if(current_allocation_period_temp < end_month){
    policy_allocation_gen(N, current_allocation_period_temp, policy_eval)
    current_allocation_period<-current_allocation_period_temp
    }
  }
  
  #to determine vaccination rates
  vaccination_rates<-array(0, dim = c(length(COMMUNITY_SET)))
  
  for (c in COMMUNITY_SET){
    R_temp<-N[N_c_r_ref[R_SUBSET, c]]
    S_temp<-N[N_c_r_ref[S_SUBSET, c]]
    if((R_temp+S_temp)>0 & (current_allocation_period_temp < end_month)){
      vaccination_rates[c]<-
        (policy_allocation_total[c, policy_eval, 
                                 current_allocation_period_temp]/
           sum(N[N_c_r_ref[ELIGIBLE_SUBSET,c]]))
    }
  }
  
  #force of infection calculations
  FOI_r<-rep(0, times = length(COMMUNITY_SET))
  for (r in COMMUNITY_SET){
   FOI_r[r]<-sum(beta_c_c[r, COMMUNITY_SET]*
     (N[N_c_r_ref[I_SUBSET, COMMUNITY_SET]]/sum(N)))
  }
  
  #Susceptible Compartments
  for (r in COMMUNITY_SET){
    dN[N_c_r_ref[S_SUBSET,r]]<- -FOI_r[r]*N[N_c_r_ref[S_SUBSET,r]] -
      N[N_c_r_ref[S_SUBSET,r]]*vaccination_rates[r]
  }
  
  #Infectious Compartments
  for (r in COMMUNITY_SET){
    dN[N_c_r_ref[I_SUBSET,r]]<-FOI_r[r]*N[N_c_r_ref[S_SUBSET,r]]+
      epsilon*FOI_r[r]*N[N_c_r_ref[R_SUBSET,r]]-
      gamma*N[N_c_r_ref[I_SUBSET,r]]-
      mu_c[r]*N[N_c_r_ref[I_SUBSET,r]]
  }
  
  #Recovered Compartments
  for (r in COMMUNITY_SET){
    dN[N_c_r_ref[R_SUBSET,r]]<- gamma*N[N_c_r_ref[I_SUBSET,r]]-
      epsilon*FOI_r[r]*N[N_c_r_ref[R_SUBSET,r]]-
      N[N_c_r_ref[R_SUBSET,r]]*vaccination_rates[r]
  }
  
  #vaccination
  for (r in COMMUNITY_SET){
    dN[N_c_r_ref[V_SUBSET,r]]<-N[N_c_r_ref[S_SUBSET,r]]*vaccination_rates[r]+
      N[N_c_r_ref[R_SUBSET,r]]*vaccination_rates[r]
  }
  
  #mortality
  for (r in COMMUNITY_SET){
    dN[N_c_r_ref[M_SUBSET,r]]<-
      mu_c[r]*N[N_c_r_ref[I_SUBSET, r]]
  }
    
    return(list(dN))
}

#Time Horizon and Evaluation intervals (1 month)
TT<-end_month-start_month
time_interval <- 1/30 #daily
TT_SET <- seq(from = 0, to = TT, by = time_interval)
out_df_all<-data.frame()

#to track allocation periods and current policy being evaluated
#(set to 0 to calculate first allocation periods)
current_allocation_period<-0
policy_eval<-1

for (p in POLICY_SET){
  
  current_allocation_period<-0
  start<-Sys.time()
  policy_eval<-p
  
  out_df<-as.data.frame(ode(times = TT_SET, y = N_init, 
                            func = SIR_VM_model, method = 'lsoda',
                            parms = NULL))
    
  out_df<- cbind(policy_id = rep(p, times = nrow(out_df)),
                 out_df)
    
  out_df_all<-rbind(out_df_all, out_df)
}
#end<-print(Sys.time()-start)
analysis_df <- melt(out_df_all, id=c("policy_id","time"))
analysis_df <- cbind(analysis_df, 
                     data.frame(do.call('rbind', 
                                        strsplit(as.character(analysis_df$variable),
                                                 '_',fixed=TRUE))))

names(analysis_df)[names(analysis_df) == "X2"] <- "COVID_compartment"
names(analysis_df)[names(analysis_df) == "X3"] <- "Region_compartment"
analysis_df = subset(analysis_df, select = -c(X1))

key_indicators_df<-analysis_df%>%
  filter(time == 6, 
         COVID_compartment == M_SUBSET)%>%
  group_by(policy_id)%>%
  summarise(total_mort = sum(value),
            max_mort = max(value))%>%
  left_join(analysis_df%>%
              filter(time == 6, COVID_compartment == V_SUBSET)%>%
              group_by(policy_id)%>%
              summarise(max_vax = round(max(value),0),
                        min_vax = round(min(value),0),
                        eq_vax = max_vax - min_vax,
                        var_vax = var(value))%>%
              mutate(equality_factor = 1- (eq_vax-min(eq_vax))/max(eq_vax)-min(eq_vax)))%>%
  ungroup()%>%
  mutate(total_mort_rank = rank(total_mort),
         max_mort_rank = rank(max_mort),
         equality_rank = rank(-equality_factor))

key_indicators_graph<-ggplot(data = key_indicators_df,
       aes(y=equality_factor, x=total_mort))+
  geom_line()+
  geom_point()+
  geom_text(label=key_indicators_df$policy_id,
            nudge_x = 0.001, nudge_y = 0.05, 
            check_overlap = F)#+
  #xlim(550, 610)

png('key_indicators_graph.png')#, width = 500, height = 500)
print(key_indicators_graph)
dev.off()

for (policy_id in POLICY_SET){
  temp_df<-as.data.frame(policy_allocation_total[COMMUNITY_SET, 
                                                 policy_id,
                                                 1:5])
  colnames(temp_df)<-1:5
  temp_df<-cbind(community_id = COMMUNITY_SET, temp_df)
  temp_df<-melt(temp_df, id.vars = c('community_id'))
  colnames(temp_df)<-c('region_id', 'allocation_period', 'number_of_vaccines_allocated')
  
  allocation_graph<-ggplot(data = temp_df, aes(x = allocation_period,
                                               y = number_of_vaccines_allocated,
                                               group = as.factor(region_id)))+
    geom_line(aes(color=as.factor(region_id)))+
    #lims(y = c(0,12000))+
    labs(title = paste0('policy ', policy_id))
  
  png(paste0('allocation_graph_policy_', policy_id, '.png'))#, width = 500, height = 500)
  print(allocation_graph)
  dev.off()
}


#write_csv(key_indicators_df, 'key_indicators_big_beta_diff.csv')

