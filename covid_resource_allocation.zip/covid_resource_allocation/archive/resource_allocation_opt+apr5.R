#model March 28th
#SIR-VM

#clean workspace
rm(list = ls())
gc()

#load packages
sapply(c('dplyr', 'deSolve', 
         'readxl', 'stringr', 
         'reshape2', 'ggplot2', 
         'varhandle', 'here', 'readr',
         'gtools', 'plotly', 'MASS'), require, character.only=T)

#set in directory and out directory
#Make sure you have the resource_allocation.Rproj open, otherwise 
#you will need to change the working directory manually.
#indir <- paste0(here(),'/param_files')
#outdir <- paste0(here(),'/model_outputs')

####4 Communities####
COMMUNITY_SET<-1:4

####5 COVID Compartments###
COVID_SET<-1:5
SIRV_SUBSET<-1:4 #for finding the denominator of FOI
ELIGIBLE_SUBSET<-c(1,3) #eligible populations
COVID_compartment_names<-c('S', 'I', 'R', 'V', 'M')

policy_df<-data.frame(permutations(n=3,r=max(COMMUNITY_SET),v=1:32,repeats.allowed=T))
names(policy_df) = COMMUNITY_SET
policy_df$policy_id = 1:nrow(policy_df)
policy_df <-melt(policy_df, id=c("policy_id"))
names(policy_df)<-c('policy_id', 'community_id', 'weight')

policy_df<-policy_df%>%
  group_by(policy_id)%>%
  mutate(total_weight = sum(weight))%>%
  mutate(percent_allocated = as.double((weight/sum(weight))))%>%
  filter(policy_id != max(total_weight))%>%
  ungroup()

policy_df<-dcast(policy_df, policy_id~community_id)
policy_df<-policy_df[2:ncol(policy_df)]
policy_df<-policy_df[!duplicated(policy_df), ]
policy_df$policy_id = 1:nrow(policy_df)

policy_df <-melt(policy_df, id=c("policy_id"))
names(policy_df)<-c('policy_id', 'community_id', 'percent_allocated')

#######Parameters########
gamma<-2 #recovery rate
epsilon<-.05 #diminished FOI
x_total<-100000 #number of vaccines allocated

community_attributes<-expand.grid('mort_rate'= c('L', 'H'), 
                                  'contact_rate' = c('L', 'H'))

community_attributes$community_id = 1:nrow(community_attributes)

#mortality rates
mu_c<-rep(0, times = length(COMMUNITY_SET))

for (c in COMMUNITY_SET){
  temp<-unlist(community_attributes['mort_rate'])
  mu_c[c]<-if_else(temp[c] == 'L', .01, .02)
}

beta_c<-rep(0, times = length(COMMUNITY_SET))

#effective contact rates
lapply(COMMUNITY_SET, function(c){
  temp<-unlist(community_attributes['contact_rate'])
  beta_c[c]<<-if_else(temp[c] == 'L', 1, 2)
})


###pop init####
S_init<-rep(0, times = length(COMMUNITY_SET))
I_init<-rep(0, times = length(COMMUNITY_SET))
R_init<-rep(0, times = length(COMMUNITY_SET))
V_init<-rep(0, times = length(COMMUNITY_SET))
M_init<-rep(0, times = length(COMMUNITY_SET))
start_pop<-rep(100000, times = length(COMMUNITY_SET))

lapply(COMMUNITY_SET, function(c){
  I_init[c]<<-.1*start_pop[c]
  S_init[c]<<-.9*start_pop[c]
}) 

SIR_VM_model <- function(time, N, parms) {
  
  dN <- array(0, dim = length(COVID_SET))
  
  #force of infection calculations
  FOI<-(beta*(N['I']/(sum(N[SIRV_SUBSET]))))
  
    # Change in S
    dN[1] <- -FOI*N['S'] -x*(N['S']/sum(N[ELIGIBLE_SUBSET]))
    
    # Change in I
    dN[2] <- FOI*N['S'] + epsilon*FOI*N['R'] - gamma*N['I']
    
    # Change in R
    dN[3]<- gamma*N['I'] - epsilon*FOI*N['R'] -x*(N['R']/sum(N[ELIGIBLE_SUBSET]))
      
    # Change in V
    dN[4]<- x
    
    # Change in M
    dN[5]<-mu*N['I']
    
    return(list(dN))
}

#Time Horizon and Evaluation intervals (1 month)
start_month = 1
end_month = 2
TT<-end_month-start_month
time_interval <- 1/30 #daily
TT_SET <- seq(from = 0, to = TT, by = time_interval)
out_df_all<-data.frame()

for (p in unique(policy_df$policy_id)){
  
  start<-Sys.time()
  
  allocation_df<-policy_df%>%
    filter(policy_id == p)%>%
    arrange(community_id)
  
  allocation_by_community<-allocation_df$percent_allocated
  
  rm(allocation_df)
  
  for (c in COMMUNITY_SET){
    x <- allocation_by_community[c]*x_total
    mu <- mu_c[c]
    beta <- beta_c[c]
    N_init<-c(S_init[c], I_init[c], R_init[c],
              V_init[c], M_init[c])
    names(N_init)<-COVID_compartment_names
    
    out_df<-as.data.frame(ode(times = TT_SET, y = N_init, 
                              func = SIR_VM_model, method = 'lsoda',
                              parms = NULL))
    
    out_df<- cbind(policy_id = rep(p, times = nrow(out_df)),
                   community_id = rep(c, times = nrow(out_df)), 
                   out_df)
    
    out_df_all<-rbind(out_df_all, out_df)
  }
  rm(allocation_by_community)
}
end<-print(Sys.time()-start)

analysis_df<-out_df_all%>%
  filter(time == 1)%>%
  group_by(policy_id)%>%
  summarise(total_mort = sum(M),
            max_mort = max(M))%>%
  mutate(total_mort_rank = rank(total_mort),
         max_mort_rank = rank(max_mort))

policy_analysis_df<-policy_df%>%
  mutate(community_id = as.integer(community_id))%>%
  left_join(community_attributes, by = c('community_id'))%>%
  mutate(mort_analysis = if_else(mort_rate == 'H', as.double(percent_allocated), 0),
         contact_rate_analysis = if_else(contact_rate == 'H', as.double(percent_allocated), 0))%>%
  mutate(co_factors_analysis = (mort_analysis+contact_rate_analysis)/2)%>%
  group_by(policy_id)%>%
  summarise(mort_analysis = sum(mort_analysis),
            contact_rate_analysis = sum(contact_rate_analysis),
            co_factors_analysis = sum(co_factors_analysis),
            equity_analysis = 1+min(percent_allocated)-max(percent_allocated))%>%
  mutate(equity_rank = rank(-equity_analysis))
         

analysis_df<-analysis_df%>%
  left_join(policy_analysis_df, by = c('policy_id'))

###ID PARETO OPTIMAL SOLUTIONS#####

###total mort vs min max###

policy_id<-c()
max_mort_factor<-c()
total_mort<-c()

for (mm in sort(unique(analysis_df$max_mort), decreasing = FALSE)){
  temp<-analysis_df%>%
    filter(max_mort == mm)
  
  mort_ref<-min(temp$total_mort)
  mm_ref<-min(temp$max_mort)
  
  temp<-temp%>%
    filter(total_mort == mort_ref)
  
  policy_id<-c(policy_id, 
               unique(temp$policy_id))
  max_mort_factor<-c(max_mort_factor, mm_ref)
  total_mort<-c(total_mort, mort_ref)
  
}

pareto_df<-data.frame(policy_id,
                      max_mort_factor,
                      total_mort)
pareto_df%>%sort()

#we know the first mm is pareto optimal
pareto_optimal_yes_no<-c('yes')
#filter dominated solutions
for (n in 2:nrow(pareto_df)){
  mm<-pareto_df$max_mort_factor[n]
  mort<-pareto_df$total_mort[n]
  
  if((pareto_df$max_mort_factor[n-1]>eq)&
     (pareto_df$total_mort[n-1]<mort)){
    pareto_optimal_yes_no<-c(pareto_optimal_yes_no, 'no')
  } else{
    pareto_optimal_yes_no<-c(pareto_optimal_yes_no, 'yes')
  }
}


pareto_df$pareto_optimal_yes_no<-pareto_optimal_yes_no

pareto_df<-pareto_df%>%
  filter(pareto_optimal_yes_no == 'yes')

pareto_optimal_yes_no<-c('yes')


analysis_df<-analysis_df%>%
  mutate(pareto_optimal = 
           if_else(policy_id %in% pareto_df$policy_id,
                   'yes', 'no'))





####total mort vs pop####
policy_id<-c()
equity_factor<-c()
total_mort<-c()


for (eq in sort(unique(analysis_df$equity_analysis), decreasing = TRUE)){
  temp<-analysis_df%>%
    filter(equity_analysis == eq)
  
  mort_ref<-min(temp$total_mort)
  equity_ref<-min(temp$equity_analysis)
  
  temp<-temp%>%
    filter(total_mort == mort_ref)
  
  policy_id<-c(policy_id, 
                                        unique(temp$policy_id))
  equity_factor<-c(equity_factor, equity_ref)
  total_mort<-c(total_mort, mort_ref)
  
}

pareto_df<-data.frame(policy_id,
                      equity_factor,
                      total_mort)

#we know the first eq is pareto optimal
pareto_optimal_yes_no<-c('yes')
#filter dominated solutions
for (n in 2:nrow(pareto_df)){
  eq<-pareto_df$equity_factor[n]
  mort<-pareto_df$total_mort[n]
  
  if((pareto_df$equity_factor[n-1]>eq)&
     (pareto_df$total_mort[n-1]<mort)){
    pareto_optimal_yes_no<-c(pareto_optimal_yes_no, 'no')
  } else{
    pareto_optimal_yes_no<-c(pareto_optimal_yes_no, 'yes')
  }
}

pareto_df$pareto_optimal_yes_no<-pareto_optimal_yes_no

pareto_df<-pareto_df%>%
  filter(pareto_optimal_yes_no == 'yes')

analysis_df<-analysis_df%>%
  mutate(pareto_optimal = 
           if_else(policy_id %in% pareto_df$policy_id,
                   'yes', 'no'))

trade_off_graph<-ggplot(analysis_df, aes(x = total_mort, y = equity_analysis, 
                        color = pareto_optimal))+
  geom_point(size = 5)+
  scale_color_manual(values=c("gray", "maroon"))+
  geom_label_repel(data=subset(analysis_df, pareto_optimal == 'yes'), 
                   nudge_x       = 32 - subset(analysis_df, pareto_optimal == 'yes')$total_mort,
                   aes(label = paste0('policy ', policy_id)),
                   box.padding   = 0, 
                   point.padding = 0,
                   segment.color = 'grey50',
                   size = 10)+
  scale_y_continuous(limits = c(0, 1.05), breaks=(seq(0, 1, .2)))+
  scale_x_continuous(limits = c(1185, 1242), breaks=(seq(1190,1240, 10)))+
  theme(legend.position='none', text = element_text(size=30), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))+
  labs(title = 'Trade-off between vaccine distribution equity and total mortality')

setwd(paste0(here(), '/model_outputs/covid_vaccines/Apr2'))
png('trade_off_graph.png', width = 1000, height = 1000)
print(trade_off_graph)
dev.off()


temp<-dcast(policy_df, policy_id~community_id)

pareto_df<-pareto_df%>%
  left_join(temp, by = c('policy_id'))

write.csv(pareto_df, 'pareto_df.csv')

###create 3D plot
fig <- plot_ly(analysis_df, x = ~co_factors_analysis,
               y = ~equity_analysis, z = ~total_mort,
               marker = list(color = ~total_mort, 
                             colorscale = c('#FFE1A1', '#683531'), showscale = TRUE))

fig <- fig %>% add_markers()
fig <- fig %>% layout(scene = list(xaxis = list(title = 'cofactors (1 is high, 0 is low)'),
                                   yaxis = list(title = 'equity (1 is high, 0 is low)'),
                                   zaxis = list(title = 'total projected mortality')))

print(fig)

ggplot(analysis_df, aes(x = total_mort, y = equity_analysis, 
                        color = as.factor(round(co_factors_analysis,1))))+
  geom_point()




