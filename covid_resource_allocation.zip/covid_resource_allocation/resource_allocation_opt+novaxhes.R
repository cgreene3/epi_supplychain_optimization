#model May 10th no vax hesitancy
#SIR-VM

#clean workspace
rm(list = ls())
gc()

#load packages
sapply(c('dplyr', 'deSolve', 
         'readxl', 'stringr', 
         'reshape2', 'ggplot2', 
         'varhandle', 'here', 'readr',
         'gtools', 'plotly', 'MASS', 'utils'), require, character.only=T)

#set in directory and out directory
#Make sure you have the resource_allocation.Rproj open, otherwise 
#you will need to change the working directory manually.
#indir <- paste0(here(),'/param_files')
outdir <- paste0(here(),'/model_outputs/covid_vaccines/May10')
setwd(outdir)

####8 REGIONS####
regional_attributes_df<-expand.grid('mort_rate'= c(.01, .05), 
                                    'initial_prevalence' = c(.005, .025),
                                    'contact_rate' = c(5, 25))
regional_attributes_df<-arrange(regional_attributes_df, initial_prevalence)
regional_attributes_df<-arrange(regional_attributes_df, contact_rate)
regional_attributes_df<-arrange(regional_attributes_df, mort_rate)

regional_attributes_df$region_id = 1:nrow(regional_attributes_df)


REGION_SET<-regional_attributes_df$region_id

####5 COVID Compartments###
COVID_SET<-1:5
SIRV_SUBSET<-1:4 #for finding the denominator of FOI
ELIGIBLE_SUBSET<-c(1,3) #eligible populations
UNVAX_SUBSET<-1:3
S_SUBSET<-1
I_SUBSET<-2
R_SUBSET<-3
V_SUBSET<-4
M_SUBSET<-5

####15 POLICIES####
policy_df<-data.frame(permutations(n=2,r=4,v=0:1,repeats.allowed=T))
colnames(policy_df)<-c('contact', 'prev', 'mort', 'pop')
policy_df<-policy_df%>%
  filter(rowSums(across(where(is.numeric)))!=0)
policy_df$sort_fact<-rowSums(policy_df)
policy_df <- subset(policy_df, select = c(pop, mort, prev, contact, sort_fact))
policy_df<-policy_df%>%
  mutate(percent_population_based = round(pop/sort_fact,2),
         percent_mortality_based = round(mort/sort_fact,2),
         percent_prevalence_based = round(prev/sort_fact,2),
         percent_effective_contact_based = round(contact/sort_fact,2))

policy_df<-arrange(policy_df, -percent_population_based)
policy_df<-arrange(policy_df, sort_fact)

policy_df <- subset(policy_df, select = c(percent_population_based,
                                          percent_mortality_based,
                                          percent_prevalence_based,
                                          percent_effective_contact_based))

policy_df$policy_id<-1:nrow(policy_df)
POLICY_SET<-policy_df$policy_id
#######Parameters########

#model evaluation
n_novax_periods = 0
n_allocation_periods = 10
TT = n_novax_periods+n_allocation_periods+1 #0 months warm up (before vaccines),
#~10 months to distribute vaccines

#other
gamma<-2 #recovery rate
epsilon<-.05 #diminished FOI
x_total<-80000 #number of vaccines allocated per month (when available)
migration_rate<-.01

#mortality rates
mu_r<-rep(0, times = length(REGION_SET))

for (r in REGION_SET){
  temp<-unlist(regional_attributes_df['mort_rate'])
  mu_r[r]<-temp[r]
}

beta_r_r<-array(0, dim = c(length(REGION_SET),
                         length(REGION_SET)))
beta_r<-rep(0, times = max(REGION_SET))
beta_r<-unlist(regional_attributes_df['contact_rate'])

#effective contact rates
lapply(REGION_SET, function(r1){
  lapply(REGION_SET, function(r2){
    r1_temp<-beta_r[r1]
    r2_temp<-beta_r[r2]
    
    beta_r_r[r1,r2]<<-if_else(r1 == r2, 1, migration_rate)*(r1_temp)^(1/2)*(r2_temp)^(1/2)
  })
})

###pop init####
N_init<-array(0, dim = c(length(COVID_SET),
                         length(REGION_SET)))

start_pop_r<-rep(100000, times = length(REGION_SET))

lapply(REGION_SET, function(r){
  temp<-unlist(regional_attributes_df['initial_prevalence'])
  N_init[I_SUBSET, r]<<-temp[r]*start_pop_r[r]
  N_init[S_SUBSET, r]<<-(1-temp[r])*start_pop_r[r]
})

compartment_names<-c()

for(r in REGION_SET){
  for(c in COVID_SET){
    compartment_names<-c(compartment_names, paste0('N_', c, '_', r))
  }
}

N_init<-c(N_init)
names(N_init)<-compartment_names


#N_ref
N_c_r_ref<-array(0, dim = c(length(COVID_SET),
                            length(REGION_SET)))
n = 1


for (r in REGION_SET){
  for (c in COVID_SET){
    N_c_r_ref[c,r]<-n
    n<-n+1
  }
}


###generate policy allocation ref####
policy_allocation_total<-array(0, dim = c(length(REGION_SET), 
                                         length(POLICY_SET),
                                         TT))

#pop allocation
policy_allocation_gen<-function(pop_current, current_allocation_period_temp, 
                                policy_eval){
    
  unvax_pop_r<-rep(0, times = length(REGION_SET))
  prev_policy_r<-rep(0, times = length(REGION_SET))
  mortality_policy_r<-rep(0, times = length(REGION_SET))
  beta_policy_r<-rep(0, times = length(REGION_SET))
  
  for (r in REGION_SET){
    
    #calculate the total unvaccined population in each state
    unvax_pop_r[r]<-max(0, sum(pop_current[N_c_r_ref[UNVAX_SUBSET, r]]))
    unvax_pop_r[r]<-if_else(is.na(unvax_pop_r[r]), 0, unvax_pop_r[r])
    
    #assign a value of 0 if everyone eligible is vaccinated
    prev_policy_r[r]<-if_else(unvax_pop_r[r] == 0, 0, pop_current[N_c_r_ref[I_SUBSET, r]])
    prev_policy_r[r]<-if_else(is.na(prev_policy_r[r]), 0, prev_policy_r[r])
    mortality_policy_r[r]<-if_else(unvax_pop_r[r] == 0, 0, mu_r[r])
    beta_policy_r[r]<-if_else(unvax_pop_r[r] == 0, 0, beta_r[r])
    
  }
  
  relative_unvax_pop_r<-unvax_pop_r/sum(unvax_pop_r)
  relative_prev_r<-prev_policy_r/sum(prev_policy_r)
  relative_mort_r<-mortality_policy_r/sum(mortality_policy_r)
  relative_beta_r<-beta_policy_r/sum(beta_policy_r)
  
  current_policy_df<-policy_df[policy_eval,] #get attributes of current policy
  #print(current_policy_df)
  policy_calc<-rep(0, times = length(REGION_SET))
  
  for (r in REGION_SET){
    if(unvax_pop_r[r] > 0){
      policy_calc[r]<-relative_unvax_pop_r[r]*unique(current_policy_df$percent_population_based)+
        relative_mort_r[r]*unique(current_policy_df$percent_mortality_based)+
        relative_prev_r[r]*unique(current_policy_df$percent_prevalence_based)+
        relative_beta_r[r]*unique(current_policy_df$percent_effective_contact_based)
    }
  }
  
  policy_calc<-policy_calc/sum(policy_calc)
  n_allocated_r<-rep(0, times = length(REGION_SET))
  
  for (r in REGION_SET){
    temp<-min(unvax_pop_r[r], round(policy_calc[r]*x_total))
    n_allocated_r[r]<-if_else(is.na(temp), 0, temp)
  }
  
  if(sum(n_allocated_r) > 0){
    n_allocated_r<-((n_allocated_r/sum(n_allocated_r))*x_total)
  }
  
  policy_allocation_total[REGION_SET,
                          policy_eval, 
                          current_allocation_period_temp]<<-round(n_allocated_r)
  
}

current_available_r<-array(0, dim = length(REGION_SET))

SIR_VM_model <- function(time, N_c_r, parms) {
  
  #print(time)
  
  dN_c_r <- array(0, dim = length(COVID_SET)*length(REGION_SET))
  
  #to determine if moving into a new resource allocation period
  current_allocation_period_temp<-as.integer(time)+1
  unvax_pop<-sum(N_c_r[N_c_r_ref[UNVAX_SUBSET, REGION_SET]])
  unvax_pop<-if_else(is.na(unvax_pop), 0, unvax_pop)
  vaccination_rates_r<-array(0, dim = length(REGION_SET))
  
  if(current_allocation_period_temp > current_allocation_period){ #if in new allocation period
    if(current_allocation_period_temp > n_novax_periods){ #if not in warmup period
      if(current_allocation_period_temp < TT){ #ensures no allocation the last month
        if(unvax_pop>0){ #if there are still people left to vaccinate
          policy_allocation_gen(N_c_r,current_allocation_period_temp,
                                policy_eval)
          current_allocation_period<-current_allocation_period_temp
          current_available_r<<-policy_allocation_total[REGION_SET,
                                  policy_eval, 
                                  current_allocation_period_temp]
        }
      }
    }
  }
  
  vaccination_rates_r<-array(0, dim = length(REGION_SET))
  
  for(r in REGION_SET){
    eligible_pop<-max(0, N_c_r[N_c_r_ref[ELIGIBLE_SUBSET, r]])
    eligible_pop<-if_else(is.na(eligible_pop), 0, eligible_pop)
    temp<-if_else(is.na(sum(N_c_r[N_c_r_ref[c(4,5), r]])), start_pop_r[r], 
                  sum(N_c_r[N_c_r_ref[c(4,5), r]]))
    if(temp < start_pop_r[r]){
      current_available<-current_available_r[r]
      if(current_available > 0){
        if(eligible_pop > 0){
          amount_given = min(eligible_pop, current_available)
          vaccination_rates_r[r]<-amount_given/eligible_pop
        }
      }
    }
  }
  
  #force of infection calculations
  FOI_r<-rep(0, times = length(REGION_SET))
  for (r in REGION_SET){
   FOI_r[r]<-sum(beta_r_r[r, REGION_SET]*
     (N_c_r[N_c_r_ref[I_SUBSET, REGION_SET]]/sum(N_c_r)))
  }
  
  #Susceptible Compartments
  for (r in REGION_SET){
    dN_c_r[N_c_r_ref[S_SUBSET,r]]<- -FOI_r[r]*N_c_r[N_c_r_ref[S_SUBSET,r]] -
      N_c_r[N_c_r_ref[S_SUBSET,r]]*vaccination_rates_r[r]
    
    current_available_r[r]<<-current_available_r[r]-
      N_c_r[N_c_r_ref[S_SUBSET,r]]*vaccination_rates_r[r]
  }
  
  #Infectious Compartments
  for (r in REGION_SET){
    dN_c_r[N_c_r_ref[I_SUBSET,r]]<-FOI_r[r]*N_c_r[N_c_r_ref[S_SUBSET,r]]+
      epsilon*FOI_r[r]*N_c_r[N_c_r_ref[R_SUBSET,r]]-
      gamma*N_c_r[N_c_r_ref[I_SUBSET,r]]-
      mu_r[r]*N_c_r[N_c_r_ref[I_SUBSET,r]]
  }
  
  #Recovered Compartments
  for (r in REGION_SET){
    dN_c_r[N_c_r_ref[R_SUBSET,r]]<- gamma*N_c_r[N_c_r_ref[I_SUBSET,r]]-
      epsilon*FOI_r[r]*N_c_r[N_c_r_ref[R_SUBSET,r]]-
      N_c_r[N_c_r_ref[R_SUBSET,r]]*vaccination_rates_r[r]
    
    current_available_r[r]<<-current_available_r[r]-
      N_c_r[N_c_r_ref[R_SUBSET,r]]*vaccination_rates_r[r]
  }
  
  #vaccination
  for (r in REGION_SET){
    dN_c_r[N_c_r_ref[V_SUBSET,r]]<-N_c_r[N_c_r_ref[S_SUBSET,r]]*vaccination_rates_r[r]+
      N_c_r[N_c_r_ref[R_SUBSET,r]]*vaccination_rates_r[r]
  }
  
  #mortality
  for (r in REGION_SET){
    dN_c_r[N_c_r_ref[M_SUBSET,r]]<-
      mu_r[r]*N_c_r[N_c_r_ref[I_SUBSET, r]]
  }
    
    return(list(dN_c_r))
} 

#Time Horizon and Evaluation intervals (1 month)
time_interval <- 1/30 #daily
TT_SET <- seq(from = 0, to = TT, by = time_interval)
out_df_all<-data.frame()

#to track allocation periods and current policy being evaluated
#(set to 0 to calculate first allocation periods)
current_allocation_period<-0
policy_eval<-1

for (p in POLICY_SET){
  
  current_allocation_period<-0
  start<-Sys.time()
  policy_eval<<-p
  print(policy_eval)
  
  out_df<-as.data.frame(ode(times = TT_SET, y = N_init, 
                            func = SIR_VM_model, method = 'euler',
                            parms = NULL))
    
  out_df<- cbind(policy_id = rep(p, times = nrow(out_df)),
                 out_df)
    
  out_df_all<-rbind(out_df_all, out_df)
}



#out_df_test<-read.csv('out.csv')

#end<-print(Sys.time()-start)
analysis_df <- melt(out_df_all, id=c("policy_id","time"))
analysis_df <- cbind(analysis_df, 
                     data.frame(do.call('rbind', 
                                        strsplit(as.character(analysis_df$variable),
                                                 '_',fixed=TRUE))))

names(analysis_df)[names(analysis_df) == "X2"] <- "COVID_compartment"
names(analysis_df)[names(analysis_df) == "X3"] <- "Region_compartment"
analysis_df = subset(analysis_df, select = -c(X1))


###to adjust total vax morts###
total_vax_mort_df<-analysis_df%>%
  group_by(policy_id, COVID_compartment, Region_compartment)%>%
  summarise(total = max(value))%>%
  filter(COVID_compartment %in% c(4,5))%>%
  group_by(policy_id, Region_compartment)%>%
  summarise(total_vax_mort = sum(total))%>%
  mutate(adj_factor = 100000/total_vax_mort,
         test = adj_factor*total_vax_mort)

vax_mort_df<-analysis_df%>%
  filter(COVID_compartment %in% c(4,5))%>%
  left_join(total_vax_mort_df, by = c('policy_id', 'Region_compartment'))%>%
  mutate(total_in_compartment = value*(adj_factor))

vax_mort_df<-subset(vax_mort_df, select = c(policy_id, time,
                                            COVID_compartment,
                                            Region_compartment,
                                            total_in_compartment))


###calculate equity factor###
eq_factor_df<-vax_mort_df%>%
  filter(COVID_compartment ==4)%>%
  group_by(time, policy_id)%>%
  summarise(vax_eq_sd = sd(total_in_compartment))%>%
  group_by(policy_id)%>%
  summarise(vax_eq_sd_total = sum(vax_eq_sd))%>%
  ungroup()%>%
  mutate(eq_factor_normalized = (vax_eq_sd_total - min(vax_eq_sd_total))/
           (max(vax_eq_sd_total) - min(vax_eq_sd_total)))%>%
  mutate(eq_factor_normalized = 1-eq_factor_normalized)%>%
  mutate(rank_eq_vax = rank(-eq_factor_normalized))

total_mort_df<-vax_mort_df%>%
  filter(COVID_compartment ==5)%>%
  group_by(policy_id, Region_compartment)%>%
  summarise(total_mort = max(total_in_compartment))%>%
  group_by(policy_id)%>%
  summarise(max_min_mort = sd(total_mort),
            total_mort = sum(total_mort))%>%
  mutate(rank_total = rank(total_mort),
         rank_max_min = rank(max_min_mort))


key_indicators_df<-eq_factor_df%>%
  left_join(total_mort_df, by = c('policy_id'))

ggplot(key_indicators_df, aes(x = total_mort,
                              y = max_min_mort))+
  geom_point()+
  geom_text(aes(label = policy_id), hjust = 1.5)

###for mortality df####
mort_df<-vax_mort_df%>%
  filter(COVID_compartment ==5)%>%
  group_by(policy_id, Region_compartment)%>%
  summarise(total_mort = max(total_in_compartment))

mort_plot_list <- list()

REGION_ORGANIZED <-c(1,5,2,6,3,7,4,8)
r_temp<-1

for(r in REGION_ORGANIZED){
  
  #position_temp<-if_else(r == 1, 'left', 'none')
  temp<-regional_attributes_df%>%filter(region_id == r)
  mort_plot_list[[r_temp]]<-ggplot(data = mort_df%>%filter(Region_compartment == r), 
                              aes(y = total_mort, x = as.factor(policy_id), 
                                  fill = as.factor(policy_id)))+
    geom_bar(stat="identity")+
    scale_fill_viridis_d()+
    theme(legend.position = 'none')+
    labs(title= paste0("Region ", r, ' (mortality rate = ', unique(temp$mort_rate),
                       ', effective contact rate = ', unique(temp$contact_rate),
                       ', init. prev. = ', unique(temp$initial_prevalence), 
                       ')'),
         x="policy", 
         y= "total mortalities")+
    ylim(0, 900)+
    theme(axis.title=element_text(size=10),
          plot.title = element_text(size = 10))
  r_temp<-r_temp+1
}


library(gridExtra)
library(grid)
grid.arrange(grobs=mort_plot_list,ncol=2)#, 
#top=textGrob("Total Mortality for Each Region by Policy"))


mort_df_summarised<-mort_df%>%
  group_by(policy_id)%>%
  summarise(total_mortalites = sum(total_mort),
            max_n_in_region = max(total_mort))



#position_temp<-if_else(r == 1, 'left', 'none')
ggplot(data = mort_df_summarised%>%arrange(total_mortalites), 
       aes(fill = as.factor(policy_id),
           x =reorder(as.factor(policy_id), total_mortalites), 
           y = total_mortalites))+
  geom_bar(stat="identity")+
  scale_fill_viridis_d()+
  theme(legend.position = 'none')+
  labs(x="policy", 
       y= "total mortalities")+
  #ylim(0, 875)+
  theme(axis.title=element_text(size=14),
        plot.title = element_text(size = 14))

ggplot(data = mort_df_summarised%>%arrange(max_n_in_region), 
       aes(fill = as.factor(policy_id),
           x =reorder(as.factor(policy_id), max_n_in_region), 
           y = max_n_in_region))+
  geom_bar(stat="identity")+
  scale_fill_viridis_d()+
  theme(legend.position = 'none')+
  labs(x="policy", 
       y= "maximum number of\nmortalities in a region")+
  #ylim(0, 875)+
  theme(axis.title=element_text(size=14),
        plot.title = element_text(size = 14))
